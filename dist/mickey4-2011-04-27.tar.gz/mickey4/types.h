bool isinteger(const char*);
bool isstring(const char*);
bool isatom(const char*);

int to_i(const char*);
