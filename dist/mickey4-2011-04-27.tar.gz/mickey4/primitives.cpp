#include <stdexcept>
#include <vector>
#include "cons.h"
#include "eval.h"
#include "primops.h"
#include "primitives.h"
#include "print.h"
#include "util.h"
#include "file_io.h"

// TODO: Fix this, had to do it because of circular cons/util deps
extern std::string to_s(cons_t*);

closure_t* lookup_closure(symbol_t *s, environment_t *env)
{
  cons_t *p = env->lookup(s->name.c_str());
  return closurep(p)? p->closure : NULL;
}

void load_default_defs(environment_t *e)
{
  e->defun("begin", defun_begin);
  e->defun("display", defun_print);
  e->defun("string-append", defun_strcat);
  e->defun("+", defun_add);
  e->defun("*", defun_mul);
  e->defun("->string", defun_to_string);
  e->defun("list", defun_list);
  e->defun("define", defun_define);
  e->defun("quote", defun_quote);
  e->defun("load", defun_load);
  e->defun("debug", defun_debug);
  e->defun("exit", defun_exit);

  // cons and friends
  e->defun("cons", defun_cons);
  e->defun("car", defun_car);
  e->defun("cdr", defun_cdr);
  e->defun("caar", defun_caar);
  e->defun("cadr", defun_cadr);
  e->defun("cdar", defun_cdar);
  e->defun("cddr", defun_cddr);
  e->defun("append", defun_append);

  // predicates
  e->defun("atom?", defun_atomp);
  e->defun("symbol?", defun_symbolp);
  e->defun("integer?", defun_integerp);
  e->defun("null?", defun_nullp);
  e->defun("pair?", defun_pairp);
}

cons_t* defun_print(cons_t *p, environment_t* env)
{
  for ( ; !nullp(p); p = cdr(p) ) {
    if ( !pairp(p) )
      printf("%s", to_s(p).c_str());
    else
      defun_print(eval(car(p), env), env);
  }

  return nil();
}

cons_t* defun_strcat(cons_t *p, environment_t* env)
{
  std::string s;

  for ( ; !nullp(p); p = cdr(p) )
    if ( !pairp(p) )
      s += to_s(p);
    else
      s += defun_strcat(eval(car(p), env), env)->string;

  return string(s.c_str());
}

cons_t* defun_add(cons_t *p, environment_t* env)
{
  /*
   * Integers have an IDENTITY, so we can do this,
   * but a more correct approach would be to take
   * the value of the FIRST number we find and
   * return that.
   */
  int sum = 0;

  for ( ; !nullp(p); p = cdr(p) ) {
    if ( integerp(p) )
      sum += p->integer;
    else if ( pairp(p) ) {
      cons_t *res = eval(car(p), env);
      if ( integerp(res) )
        sum += res->integer; // or else, thow (TOWO)
    } else
      throw std::runtime_error("Cannot add integer and " + to_s(type_of(p)));
  }

  return integer(sum);
}

cons_t* defun_mul(cons_t *p, environment_t *env)
{
  // Identity; see defun_add
  int product = 1;

  for ( ; !nullp(p); p = cdr(p)) {
    if ( integerp(p) )
      product *= p->integer;
    else if ( pairp(p) ) {
      cons_t *res = eval(car(p), env);
      if ( integerp(res) )
        product *= res->integer; // else, throw (TODO)
    } else
      throw std::runtime_error("Cannot multiply with type " + to_s(type_of(p)));
  }

  return integer(product);
}

cons_t* defun_begin(cons_t* p, environment_t *env)
{
  // execute in order of appearance
  cons_t *r = NULL;

  for ( ; !nullp(p); p = cdr(p) )
    if ( !pairp(p) )
      r = append(r, eval(p, env));
    else
      r = append(r, eval(car(p), env));

  return r;
}

cons_t* defun_to_string(cons_t* p, environment_t *env)
{
  std::string s;

  for ( ; !nullp(p); p = cdr(p)) {
    if ( integerp(p) )
      s += format("%d", p->integer);
    else if ( stringp(p) )
      s += p->string;
    else if ( pairp(p) )
      s += sprint(eval(car(p), env));
  }

  return string(s.c_str());
}

cons_t* defun_list(cons_t* p, environment_t *env)
{
  cons_t *l = NULL;

  for ( ; !nullp(p); p = cdr(p))
    if ( !pairp(p) )
      l = append(l, p);
    else
      l = append(l, cons(eval(car(p), env)));

  return l;
}

cons_t* defun_define(cons_t *p, environment_t *env)
{
  /*
   * Format: (define <name> <body>)
   */

  cons_t *name = car(p);
  cons_t *body = eval(cdr(p), env);

  if ( !symbolp(name) )
    throw std::runtime_error("First argument to (define) must be a symbol");

  /*
   * Ugly hack:  If we do (define a 123) we get car(body)=123 and cdr(body)=nil,
   *             but if we do (define a (list 1 2 3)) we get car(body)=nil and cdr(body)=list(1 2 3)
   *
   *             This is probably due to bugs in the parser, so fixing that is a big TODO.
   */
  if ( nullp(car(body)) && !nullp(cdr(body)) )        //
    body = cdr(body);                                 // <= THIS IS UGLY
  else if ( !nullp(car(body)) && nullp(cdr(body)) )   // <= AND WRONG
    body = car(body);                                 // <= AND MUST BEGONE!
  else if ( !nullp(car(body)) && !nullp(cdr(body)) )  //
    body = cadr(body);

  env->define(name->symbol->name, body);
  return nil();
}

cons_t* defun_quote(cons_t *p, environment_t *env)
{
  // just pass along data without performing eval()
  return nullp(cdr(p)) ? car(p) : cadr(p);
}

cons_t* defun_load(cons_t *filename, environment_t *env)
{
  if ( !stringp(car(filename)) )
    throw std::runtime_error("First argument to (load) must be a file name");

  program_t *p = parse(slurp(open_file(car(filename)->string)).c_str(), env);

  // When reading from disk, we implicitly wrap it all in (begin ...)
  p->root = cons(cons(env->lookup("begin"), p->root));

  eval(p);
  return nil();
}

cons_t* defun_debug(cons_t *p, environment_t *env)
{
  std::string s;

  s = format("adr=%-11p type=%-7s", p, to_s(type_of(p)).c_str());

  if ( !nullp(p) )
  switch ( type_of(p) ) {
  case NIL:
    break;
  case INTEGER:
    s += format(" value=%d", p->integer);
    break;
  case CLOSURE:
    s += format(" function=%p environment=%p", p->closure->function, p->closure->environment);
    break;
  case PAIR:
    s += format(" car=%p cdr=%p", p->car, p->cdr);
    break;
  case SYMBOL:
    s += format(" name='%s'", p->symbol->name.c_str());
    break;
  case STRING:
    s += format(" value='%s'", p->string);
    break;
  case U8VECTOR:
    break;
  case CONTINUATION:
    break;
  }

  s += "\n";

  if ( type_of(p) == PAIR ) {
    s += defun_debug(car(p), env)->string;
    s += defun_debug(cdr(p), env)->string;
  }

  return string(s.c_str());
}

cons_t* defun_exit(cons_t* p, environment_t*)
{
  exit(integerp(car(p))? car(p)->integer : 0);
  return NULL;
}

cons_t* defun_cons(cons_t* p, environment_t* e)
{
  return cons(car(p), cadr(p));
}

cons_t* defun_car(cons_t* p, environment_t*)
{
  return car(p);
}

cons_t* defun_cdr(cons_t* p, environment_t*)
{
  return cdr(p);
}

cons_t* defun_caar(cons_t* p, environment_t*)
{
  return caar(p);
}

cons_t* defun_cadr(cons_t* p, environment_t*)
{
  return cadr(p);
}

cons_t* defun_cdar(cons_t* p, environment_t*)
{
  return cdar(p);
}

cons_t* defun_cddr(cons_t* p, environment_t*)
{
  return cddr(p);
}

cons_t* defun_append(cons_t* p, environment_t*)
{
  return append(car(p), cadr(p));
}

cons_t* defun_atomp(cons_t* p, environment_t*)
{
  return integer(atomp(p));
}

cons_t* defun_symbolp(cons_t* p, environment_t*)
{
  return integer(symbolp(p));
}

cons_t* defun_integerp(cons_t* p, environment_t*)
{
  return integer(integerp(p));
}

cons_t* defun_nullp(cons_t* p, environment_t*)
{
  return integer(nullp(p));
}

cons_t* defun_pairp(cons_t* p, environment_t*)
{
  return integer(pairp(p));
}
