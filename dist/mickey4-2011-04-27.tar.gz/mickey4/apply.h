#include "cons.h"

cons_t* apply(lambda_t f, cons_t *args, environment_t *env);
