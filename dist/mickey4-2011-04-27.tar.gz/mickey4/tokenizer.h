#ifndef INC_MICKEY_TOKENIZER_H
#define INC_MICKEY_TOKENIZER_H

void set_source(const char* program);
const char* get_token();

#endif
